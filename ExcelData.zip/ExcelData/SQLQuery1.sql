use AONDemoDB

create table Emp
(id int primary key,
name nvarchar(255),
dept nvarchar(255),
desg nvarchar(255),
salary nvarchar(255))


create table Loc
(id int primary key,
LocationName nvarchar(255),
Address nvarchar(255),
PinCode nvarchar(255))
