﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityLayer;
using BAL;
namespace MVCFramework.Controllers
{
    public class CustomerMVCController : Controller
    {
        // GET: CustomerMVC
        CustomerBAL bal = new CustomerBAL();
        public ActionResult SelectAllCustomer()
        {
            var res = bal.SelectAllCustomer();
            return View(res);
        }
        [HttpGet]
        public ActionResult InsertCustomer()
        {
            return View();
        }
        [HttpPost]
        public ActionResult InsertCustomer(CustomerEntity entity)
        {
            if(ModelState.IsValid)
            {
                var res=bal.InsertCustomer(entity);
                if (res)
                    return RedirectToAction("SelectAllCustomer");
            }
            return View();
        }
        
             

    }
}