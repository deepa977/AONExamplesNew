﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DAL;
using System.Text.RegularExpressions;
namespace BAL
{
    public class CustomerBAL
    {
        CustomerDAL dal = new CustomerDAL();
        public bool InsertCustomer(CustomerEntity entity)
        {
            if (string.IsNullOrEmpty(entity.Address))
                throw new Exception("Address cannot be blank");
            Regex pattern = new Regex(@"\d{10}");
            if (pattern.IsMatch(entity.MobNo.ToString()))
            {

            }
            else
                throw new Exception("MobNo not valid");
            return dal.InsertCustomer(entity);

                     
        }
        public IEnumerable<CustomerEntity> SelectAllCustomer()
        {
            return dal.SelectAllCustomer();
        }
    }
}
