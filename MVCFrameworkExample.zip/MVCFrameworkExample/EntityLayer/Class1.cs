﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace EntityLayer
{
    public class CustomerEntity
    {
        [Key]
        public int CustomerID { get; set; }
        [Required(ErrorMessage ="Name cannot be blank")]
        public string Name { get; set; }
        public  string Address { get; set; }
        public string Email { get; set; }
        public long MobNo { get; set; }
    }
}
