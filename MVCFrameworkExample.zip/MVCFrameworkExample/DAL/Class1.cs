﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data.SqlClient;
namespace DAL
{
    public class CustomerDAL
    {
        string connstr = "Data Source=(localdb)\\MSSqlLocalDB;Initial Catalog=AONDemoDB;Integrated Security=True";
        SqlConnection con = null;
        SqlCommand com = null;
        SqlDataReader r = null;
        public bool InsertCustomer(CustomerEntity entity)
        {
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "insert into customer values(@nm,@add,@em,@mno)";
                com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@nm", entity.Name);
                com.Parameters.AddWithValue("@add", entity.Address);
                com.Parameters.AddWithValue("@em", entity.Email);
                com.Parameters.AddWithValue("@mno", entity.MobNo);
                var res = com.ExecuteNonQuery();
                if (res > 0)
                    return true;
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return false;
        }

        public IEnumerable<CustomerEntity> SelectAllCustomer()
        {
            List<CustomerEntity> lst = new List<CustomerEntity>();
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "select * from Customer";
                com = new SqlCommand(query, con);
                SqlDataReader r = com.ExecuteReader();
                while(r.Read())
                {
                    CustomerEntity entity = new CustomerEntity();
                    entity.CustomerID = (int)r[0];
                    entity.Name = r[1].ToString();
                    entity.Address = r[2].ToString();
                    entity.Email = r[3].ToString();
                    entity.MobNo = (long)r[4];
                    lst.Add(entity);
                }
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return lst;
        }

    }
}
