﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    interface IPrint
    {
        void Print();
    }
}
