﻿using System;

namespace DIExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How to you want the printed output");
            Console.WriteLine("1.PDF File");
            Console.WriteLine("2.TExt File");
            Console.WriteLine("3.Log File");
            Console.WriteLine("4.Email");
            int ch = int.Parse(Console.ReadLine());
            switch(ch)
            {
                case 1: PDFFile pdf = new PDFFile();
                    pdf.Print();
                    break;
                case 2: TextFile text = new TextFile();
                    text.Print();
                    break;
                case 3:LoggerFile log = new LoggerFile();
                    log.Print();
                    break;
                case 4: EmailFormat email = new EmailFormat();
                    email.Print();
                    break;
            }
            //UI -> oPDF oText oEmail oLogger oSMS
           /* string type=radiobutton.checked.value;*/
            ConstructorInjection obj = new ConstructorInjection(new LoggerFile());
            obj.Print();

        }
    }
}
