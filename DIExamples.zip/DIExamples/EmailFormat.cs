﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    class EmailFormat : IPrint
    {
        public void Print()
        {
            Console.WriteLine("Printing details in Email");
        }
    }
}
