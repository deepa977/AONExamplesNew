﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    class LoggerFile : IPrint
    {
        public void Print()
        {
            Console.WriteLine("Printing the details in a Event Log");
        }
    }
}
