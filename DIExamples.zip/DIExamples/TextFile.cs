﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    class TextFile : IPrint
    {
        public void Print()
        {
            Console.WriteLine("Printing the details in a Text File");
        }
    }
}
