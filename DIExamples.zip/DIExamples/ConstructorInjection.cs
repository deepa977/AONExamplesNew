﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    class ConstructorInjection
    {
        IPrint _print;
        public ConstructorInjection(IPrint _print)
        {
            this._print = _print;
        }
        public void Print()
        {
            _print.Print();
        }
    }
}
