﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExamples
{
    class PDFFile : IPrint
    {
        public void Print()
        {
            Console.WriteLine("Printing the details in a PDF File");
        }
    }
}
