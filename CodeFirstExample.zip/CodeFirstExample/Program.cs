﻿using System;
using EFCoreDemo;
using System.Linq;
namespace CodeFirstExample
{
    class Program
    {
        static void Main(string[] args)
        {
           EFCoreContext dbcontext=new EFCoreContext();
           var t=dbcontext.Database.BeginTransaction();
           Author newauthor=
           new Author{FirstName=" R K",LastName="Narayan"};
            dbcontext.Authors.Add(newauthor);
            var res=dbcontext.SaveChanges();
            var aid=newauthor.AuthorID;
            Console.WriteLine(aid);
           Book newbook=new Book{Title="Malgudi Days",
           AuthorId=aid};
          
           dbcontext.Books.Add(newbook);
            res=dbcontext.SaveChanges();
            t.Commit();
           if(res > 0)
             Console.WriteLine("DB Created, Tables Created and added data");

        }
    }
}
