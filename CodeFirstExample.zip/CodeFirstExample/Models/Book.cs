using System.ComponentModel.DataAnnotations;
namespace EFCoreDemo
{
    public class Book{
        [Key]
        public int BookId{get;set;}
        [Required]
        public string Title{get;set;}
        public int AuthorId{get;set;}
        public double Price{get;set;}
        public  Author Author {get;set;}
        //before the relationship property if virtual keyword is used that means
        //lazy loading is enabled


    }
}