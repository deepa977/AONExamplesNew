using Microsoft.EntityFrameworkCore;
/*using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;*/
namespace EFCoreDemo
{
    public class EFCoreContext:DbContext
    {
        public DbSet<Book> Books{get;set;}
        public DbSet<Author> Authors{get;set;}
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            //this is the sql server context in which the tables has to get created
            options.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;
            Database=AONCodeFirstDB;Trusted_Connection=True;
            MultipleActiveResultSets=True;");
        }
        public EFCoreContext():base()
        {
            //this.Configuration.LazyLoadingEnabled=false;
        }
    }
}