using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace EFCoreDemo

{
    public class Author
    {
         [Key]
         //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AuthorID{get;set;}
        public string FirstName { get; set; }
        public string LastName{get;set;}
        public ICollection<Book> Books{get;set;}=new List<Book>();
        //virtual keyword will enable lazy loading when the object of Book is getting
        //created it will dynamically create the object of Authors also so that
        //along with Book the properties of Author can also be accessed
    }
}