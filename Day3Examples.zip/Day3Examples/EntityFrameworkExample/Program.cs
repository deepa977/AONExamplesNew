﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //insert data to Customer
            //Entire DB connection is defined in the class AONDemoDBEntities
            AONDemoDBEntities db = new AONDemoDBEntities();
            Customer newcust = new Customer();
            Console.WriteLine("Enter Customer Name");
            newcust.Name = Console.ReadLine();
            Console.WriteLine("Enter Customer Address");
            newcust.Address = Console.ReadLine();
            Console.WriteLine("Enter Email");
            newcust.Email = Console.ReadLine();
            Console.WriteLine("Enter MobNo");
            newcust.MobNO = long.Parse(Console.ReadLine());
            db.Customers.Add(newcust); //insert to conceptual model
            var res = db.SaveChanges(); // this method will update changes to DB 
            if (res > 0)
                Console.WriteLine("New Customer Inserted");


            Console.WriteLine("Select Data from Customer");
            var result = db.Customers.ToList();
            foreach(var r in result)
            {
                Console.WriteLine(r.CustomerID + "," + r.Name + "," + r.Address + "," + r.Email + "," + r.MobNO);
                Console.WriteLine("****************");
            }



            //select data from Customer Table
        }
    }
}
