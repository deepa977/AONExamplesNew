create database AONDemoDB

use AONDemoDB

--identity will auto generate the numbers
--(100,100) start with 100 and increment by 100. 
Create table Customer
(CustomerID int primary key identity(100,100),
Name varchar(50) not null,
Address varchar(100) not null,
Email varchar(50) not null,
MobNO bigint not null)

create table Accounts
(AccID bigint primary key,
 CustomerID  int references Customer(CustomerID),
 AccType varchar(50) not null,
 Status varchar(50) not null,
 Balance money not null)

 create table [Transaction]
 (TransactionID int primary key identity,
 AccID bigint references Accounts(AccID),
 TransType varchar(50) not null,
 TransAmount money not null)

