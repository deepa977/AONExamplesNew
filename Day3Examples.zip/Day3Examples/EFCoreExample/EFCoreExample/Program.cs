﻿using System;
using System.Linq;
using EFCoreExample.Models;
namespace EFCoreExample
{
    class Program
    {
        static void Main(string[] args)
        {
            AONDemoDBContext db = new AONDemoDBContext();
            
            Customer newcust = new Customer();
            Console.WriteLine("Enter Customer Name");
            newcust.Name = Console.ReadLine();
            Console.WriteLine("Enter Customer Address");
            newcust.Address = Console.ReadLine();
            Console.WriteLine("Enter Email");
            newcust.Email = Console.ReadLine();
            Console.WriteLine("Enter MobNo");
            newcust.MobNo = long.Parse(Console.ReadLine());
            db.Customer.Add(newcust); //insert to conceptual model
            var res = db.SaveChanges(); // this method will update changes to DB 
            if (res > 0)
                Console.WriteLine("New Customer Inserted");


            Console.WriteLine("Select Data from Customer");
            var result = db.Customer.ToList();
            foreach (var r in result)
            {
                Console.WriteLine(r.CustomerId + "," + r.Name + "," + r.Address + "," + r.Email + "," + r.MobNo);
                Console.WriteLine("****************");
            }

        }
    }
}
