﻿using System;
using System.Collections.Generic;

namespace EFCoreExample.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Accounts = new HashSet<Accounts>();
        }

        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public long MobNo { get; set; }

        public ICollection<Accounts> Accounts { get; set; }
    }
}
