﻿using System;
using System.Collections.Generic;

namespace EFCoreExample.Models
{
    public partial class Transaction
    {
        public int TransactionId { get; set; }
        public long? AccId { get; set; }
        public string TransType { get; set; }
        public decimal TransAmount { get; set; }

        public Accounts Acc { get; set; }
    }
}
