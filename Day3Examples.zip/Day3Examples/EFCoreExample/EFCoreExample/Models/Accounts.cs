﻿using System;
using System.Collections.Generic;

namespace EFCoreExample.Models
{
    public partial class Accounts
    {
        public Accounts()
        {
            Transaction = new HashSet<Transaction>();
        }

        public long AccId { get; set; }
        public int? CustomerId { get; set; }
        public string AccType { get; set; }
        public string Status { get; set; }
        public decimal Balance { get; set; }

        public Customer Customer { get; set; }
        public ICollection<Transaction> Transaction { get; set; }
    }
}
