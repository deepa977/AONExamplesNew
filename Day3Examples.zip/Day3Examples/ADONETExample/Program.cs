﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADONETExample
{
    class Program
    {
        static void Main(string[] args)
        {
            DBConnect db = new DBConnect();
            for(int i=0;i<3;i++)
            {
                CustomerEntity ce = new CustomerEntity();
                Console.WriteLine("Enter Customer Name");
                ce.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Customer Address");
                ce.Address = Console.ReadLine();
                Console.WriteLine("Enter Customer EMail");
                ce.Email = Console.ReadLine();
                Console.WriteLine("Enter MobNo");
                ce.MobNo = long.Parse(Console.ReadLine());
                var res = db.InsertCustomer(ce);
                if (res)
                    Console.WriteLine("New Customer Inserted");
            }
            var op = db.SelectCustomer();
            Console.WriteLine("Customer details from DBTable");
            foreach(var r in op)
            {
                Console.WriteLine(r.CustomerID + "," + r.CustomerName + "," + r.Address + "," + r.Email + "," + r.MobNo);
            }
        }
    }
}
