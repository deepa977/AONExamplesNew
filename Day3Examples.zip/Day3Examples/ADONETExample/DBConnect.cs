﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ADONETExample
{
    class DBConnect
    {
        SqlConnection con = null;//we will connection parameters to connect to DB
        SqlCommand cmd = null;// sql query is given in this class
        SqlDataReader r = null; // read the data fetched from the DB
        //Data Source-From which system  SQL Server is accessed
        //Initial Catalog - DB name
        //SQl server is using default windows credentials to connect
        //Integrated Security=True
        string dbconnectparam = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AONDemoDB;Integrated Security=True";

        public bool InsertCustomer(CustomerEntity entity)
        {
            try
            {
                con = new SqlConnection(dbconnectparam);
                //it will connection to DB
                con.Open();//it will activate the connection
                string query = "insert into customer values(@nm,@add,@em,@mno)";
                //parameters in sql server starts with @variable name
                //parameter name need not be same as column name
                //it is used to initialize the values for the parameter
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nm", entity.CustomerName);
                cmd.Parameters.AddWithValue("@add", entity.Address);
                cmd.Parameters.AddWithValue("@em", entity.Email);
                cmd.Parameters.AddWithValue("@mno", entity.MobNo);
                var res = cmd.ExecuteNonQuery();
                //res will store the number of rows inserted after executing the query
                if (res > 0)
                    return true;

            }
            catch(Exception ex)
            {
                throw ex;
            }
            //finally block executes whether an exception occurs or not
            finally
            {
                con.Close();
            }
            return false;

        }
        public List<CustomerEntity> SelectCustomer()
        {
            List<CustomerEntity> lst = new List<CustomerEntity>();
            try
            {
                con = new SqlConnection(dbconnectparam);
                con.Open();
                string query = "select * from Customer";
                //it is an sql query which will retreive all data from the table
                cmd = new SqlCommand(query, con);
                r = cmd.ExecuteReader();//this method will execute the select query and store the o/p fetched from the table in DataReader object - r object
                while(r.Read())
                {
                    //read will advance to next row and read the data
                    //it will executing the while loop till the reader reaches EO Records
                    CustomerEntity ce = new CustomerEntity();
                    ce.CustomerID = (int)r[0];
                    ce.CustomerName = r[1].ToString();
                    ce.Address = r[2].ToString();
                    ce.Email = r[3].ToString();
                    ce.MobNo = (long)r[4];
                    lst.Add(ce);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally block executes whether an exception occurs or not
            finally
            {
                con.Close();
            }
            return lst;

        }
    }
}
