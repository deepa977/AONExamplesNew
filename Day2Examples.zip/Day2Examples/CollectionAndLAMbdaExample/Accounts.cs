﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionAndLAMbdaExample
{
    class Accounts
    {
        //type prop and press tab twice
        public long AccountID { get; set; }
        public string Name { get; set; }
        public string AccountType { get; set; }
        public double Balance { get; set; }
    }
}
