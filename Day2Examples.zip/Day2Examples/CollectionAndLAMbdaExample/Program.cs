﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace CollectionAndLAMbdaExample
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Accounts> acc = new List<Accounts>();
            acc.Add(new Accounts { AccountID = 1234, Name = "Martin", AccountType = "Savings", Balance = 12500 });
            acc.Add(new Accounts { AccountID = 1245, Name = "King", AccountType = "Current", Balance = 75000 });
            //collection initializer .net 3.5 onwards
            List<Accounts> lstaccts = new List<Accounts>()
            {
                new Accounts{AccountID=1,Name="Blake",AccountType ="Savings",Balance=5000},
                new Accounts{AccountID=2,Name="Clark",AccountType="Current",Balance=100000},
                new Accounts{AccountID=3,Name="Ford",AccountType="Savings",Balance=7500},
                new Accounts{AccountID=4,Name="Smith",AccountType="Recurring",Balance=30000}
            };
            Console.WriteLine("Get All the data");
            foreach (Accounts a in acc)
                Console.WriteLine(a.AccountID + "" + a.Name + " " + a.AccountType + " " + a.Balance);
            Console.WriteLine("Enter Account Type ");
            string atype = Console.ReadLine();
            int flag = 0;
            foreach(Accounts a in acc)
            {
                if (a.AccountType == atype)
                {
                    Console.WriteLine(a.AccountID + "" + a.Name + " " + a.AccountType + " " + a.Balance);
                    flag = 0;
                    break;

                }
                else
                    flag = 1;
            }
            if (flag == 1)
                Console.WriteLine("Invalid Acctype");
            //lambda expression
            //implicit variables
            //rather than giving the actual datatype for capturing the value returned , we use implicit variables
            //implicit variables are delared using var keyword
            //it will determine the datatype at compile time based on the value initialized to it
            var result=lstaccts.Where(x => x.AccountType == atype);
            if (result.Count() == 0)
                Console.WriteLine("Invalid Account type");
            else
                foreach (var r in result)
                    Console.WriteLine(r.AccountID + " " + r.Name + " " + r.AccountType + "" + r.Balance);

            //multiple condition
            var result1 = lstaccts.Where(n => n.AccountType == "Savings" && n.Balance >= 5000);

            //linq query
            var result2 = from t in lstaccts
                          where t.Balance > 15000 && t.AccountType=="Current"
                          select t;
            foreach(var r in result2)
                Console.WriteLine(r.AccountID + " " + r.Name + " " + r.AccountType + "" + r.Balance);



        }
    }
}
