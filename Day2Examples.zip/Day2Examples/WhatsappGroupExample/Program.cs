﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatsappGroupExample
{
    class Program
    {
        //create a delegate
        public delegate void SMS(string m);
        static void Main(string[] args)
        {
            //initialize the delegate
            CollegeGroup clg = new CollegeGroup();
            OfficeGroup office = new OfficeGroup();
            SMS sms = clg.Message;
            sms += office.Message;
            sms("Good Morning !!!");
            sms -= office.Message;

            sms("Alumni meet at college this sunday @4pm.All r invited");
            sms -= clg.Message;
            sms += office.Message;
            sms("Team Meeting at 4pm to discuss project updates");


        }
    }
}
