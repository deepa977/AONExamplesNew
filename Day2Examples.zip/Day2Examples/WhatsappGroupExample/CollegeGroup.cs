﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatsappGroupExample
{
    class CollegeGroup
    {
        long[] mobno = new long[3];
        public CollegeGroup()
        {
            mobno[0] = 8999012345;
            mobno[1] = 6778912456;
            mobno[2] = 9985088899;

        }
        public void Message(string msg)
        {
            foreach(long m in mobno)
            {
                Console.WriteLine("College Group:" + m + "-" + msg);
            }
        }
    }
}
