﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatsappGroupExample
{
    class OfficeGroup
    {
        long[] mobno = new long[3];
        public OfficeGroup()
        {
            mobno[0] = 7999012300;
            mobno[1] = 9778912400;
            mobno[2] = 8985088800;

        }
        public void Message(string msg)
        {
            foreach (long m in mobno)
            {
                Console.WriteLine("Office Group:" + m + "-" + msg);
            }
        }
    }
}
