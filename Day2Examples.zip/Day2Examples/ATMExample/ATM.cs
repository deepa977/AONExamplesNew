﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATMExample
{
    class ATM
    {
        int accid;
        string name;
        double balance;
        public ATM()
        {
            accid = 1000;
            name = "Martin";
            balance = 5000;
        }
        public delegate void TransactionMessage(string message);
        public delegate void TransactionMessageForBalance();
        //events are associated with delegates,the events will trigger based on a condition
        public event TransactionMessage OnTransactionChange;
        public event TransactionMessageForBalance OnTransactionChangePrint;
        public void ValidatePin(int pinno)
        {
            if (pinno == 1234)
                OnTransactionChange("Pin validated... Continue your transaction");
            else
                OnTransactionChange("Invalid Pin.You can try again else card will be blocked.....");

        }
        public void Deposit(int amt)
        {
            if(amt%100==0)
            {
                balance += amt;
                OnTransactionChange("Amount Depoited,Wait for 30Mins to reflect in your account.....");
            }
            else
            {
                OnTransactionChange("Deposit amount in multiples of 100,Transaction failed....");
            }

        }
        public void Withdraw(int amt)
        {
            if (amt > balance)
                OnTransactionChange("Insufficient balance,cannot withdraw...");
            else if (amt % 100 != 0)
                OnTransactionChange("Withdraw in multiples of 100");
            else
            {
                balance -= amt;
                OnTransactionChange("Transaction Successful. You have withdraw: " + amt);
            }
        }
        //string msg = null;
        public void ShowBalance()
        {
           OnTransactionChange("Current Balance:" + balance);

        }
        public void TransactionSlip(string msg)
        {
            Console.WriteLine(msg);
            /*string subscription = "email";
            if(subscription=="email")
            {
                WebEmail we = new WebEmail();
                we.mailalert(msg);
            }*/

        }
        //event will check the condition
        //based on condition different transaction status is updated
        //it will send the notification of the updated message to delegate
        // delegate will print the different notification thru TransactionSlip




    }
}
