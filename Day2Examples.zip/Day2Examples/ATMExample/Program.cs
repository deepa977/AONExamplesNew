﻿using System;

namespace ATMExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ATM atm = new ATM();
            atm.OnTransactionChange += new ATM.TransactionMessage(atm.TransactionSlip);
            //events will check for condition
            //based on condition it will update the notification
            //notification is received by delegate
            //delegate will use the methods TransactionSlip to print the notification messages
            atm.ValidatePin(0000);
            atm.ValidatePin(1234);
            atm.Deposit(555);
            atm.Deposit(2000);
            atm.Withdraw(80000);
            atm.Withdraw(1234);
            atm.Withdraw(500);
            atm.ShowBalance();


        }
    }
}
