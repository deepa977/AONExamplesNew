﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingAPI.Models
{
    public class CustomClass
    {
        public int AccID { get; set; }
        public string Name { get; set; }
        public int CustomerId { get; set; }
        public decimal Balance { get; set; }
        public string TransType { get; set; }
        public decimal TransAmount { get; set; }
    }
}
