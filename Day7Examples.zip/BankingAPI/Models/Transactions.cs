﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingAPI.Models
{
    public class Transactions
    {
        public int TransactionId { get; set; }
        public int AccID { get; set; }
        public string TransType { get; set; }
        public decimal TransAmount { get; set; }
    }
}
