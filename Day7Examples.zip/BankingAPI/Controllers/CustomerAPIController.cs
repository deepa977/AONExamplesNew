﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using BankingAPI.Models;
using System.Web.Http;
using Microsoft.AspNetCore.Cors;

namespace BankingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
        public class CustomerAPIController : ControllerBase
    {
        private readonly string connstr = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AONDemoDB;Integrated Security=True;";
        SqlConnection con = null;
        SqlDataReader r = null;
        SqlCommand cmd = null;
        [Microsoft.AspNetCore.Mvc.HttpGet]
        [Route("/api/CustomerAPI/GetCustomerByID/{id}")]
        public Customer Get([FromUri]int id)
        {
            Customer c = new Customer();
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "select * from Customer where CustomerID=" + id;
                cmd = new SqlCommand(query, con);
                r = cmd.ExecuteReader();
                if(r.Read())
                {
                    c.CustomerId = Convert.ToInt32(r[0]);
                    c.Name = r[1].ToString();
                    c.Address = r[2].ToString();
                    c.Email = r[3].ToString();
                    c.MobNo = Convert.ToInt64(r[4]);
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return c;
        }

        [Microsoft.AspNetCore.Mvc.HttpGet]
        [Route("/api/CustomerAPI/GetAllCustomer")]
        public IEnumerable<Customer> Get()
        {
            List<Customer> cust = new List<Customer>();
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "select * from customer";
                cmd = new SqlCommand(query, con);
                r = cmd.ExecuteReader();
                while(r.Read())
                {
                    Customer c = new Customer();
                    c.CustomerId = Convert.ToInt32(r[0]);
                    c.Name = r[1].ToString();
                    c.Address = r[2].ToString();
                    c.Email = r[3].ToString();
                    c.MobNo = Convert.ToInt64(r[4]);
                    cust.Add(c);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return cust;
        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        
        public bool Post([System.Web.Http.FromBody]Customer cust)
        {
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "insert into Customer values(@nm,@add,@em,@mno)";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nm", cust.Name);
                cmd.Parameters.AddWithValue("@add", cust.Address);
                cmd.Parameters.AddWithValue("@em", cust.Email);
                cmd.Parameters.AddWithValue("@mno", cust.MobNo);
                var res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return false;
        }
    }
}