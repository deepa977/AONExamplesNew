﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using MongoDBandMVC.Models;
namespace MongoDBandMVC.Controllers
{
    public class EmployeeController : Controller
    {
        private IMongoDatabase database;
        public IMongoDatabase GetConnection()
        {
            var client = new MongoClient("mongodb://localhost:27017");
            return client.GetDatabase("AONDemoDB");
        }
        public IActionResult SelectAllEmployee()
        {
            database = GetConnection();
            var result = database.GetCollection<Employee>("employee").Find(FilterDefinition<Employee>.Empty).ToList();
            return View(result);
        }
        [HttpGet]
        public IActionResult InsertEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult InsertEmployee(Employee emp)
        {
            try
            {
                database = GetConnection();
                database.GetCollection<Employee>("employee").InsertOne(emp);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return RedirectToAction("SelectAllEmployee");
        }
        [HttpGet]
        public IActionResult EditEmployee(int ?id=0)
        {
            database = GetConnection();
            var result = database.GetCollection<Employee>("employee").Find<Employee>(x => x.empid == id).SingleOrDefault();
            if (result == null)
                return NotFound();
            else
                return View(result);
        }
        [HttpPost]
        public IActionResult EditEmployee(Employee emp)
        {
            try
            {
                database = GetConnection();
                var filters = Builders<Employee>.Filter.Eq("empid", emp.empid);
                var updatestatement = Builders<Employee>.Update.Set("empid", emp.empid);
                updatestatement = updatestatement.Set("name", emp.name);
                updatestatement = updatestatement.Set("dept", emp.dept);
                updatestatement = updatestatement.Set("desg", emp.desg);
                updatestatement = updatestatement.Set("salary", emp.salary);
                var result = database.GetCollection<Employee>("employee").UpdateOne(filters, updatestatement);
                if (result.IsAcknowledged == false)
                    return BadRequest("Unable to update the employee");
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return RedirectToAction("SelectAllEmployee");
        }
        [HttpGet]
        public IActionResult DeleteEmployee(int? id = 0)
        {
            database = GetConnection();
            var result = database.GetCollection<Employee>("employee").Find<Employee>(x => x.empid == id).SingleOrDefault();
            if (result == null)
                return NotFound();
            else
                return View(result);
        }
        [HttpPost]
        public IActionResult DeleteEmployee(Employee emp)
        {
            try
            {
                database = GetConnection();
                var result = database.GetCollection<Employee>("employee").DeleteOne(x => x.empid == emp.empid);
                if(result.IsAcknowledged==false)
                {
                    return BadRequest("Unable to delete employee");
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return RedirectToAction("SelectAllEmployee");
        }
    }
}