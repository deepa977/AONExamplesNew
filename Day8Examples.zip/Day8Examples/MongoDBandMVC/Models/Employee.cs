﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson.Serialization.Attributes;
namespace MongoDBandMVC.Models
{
    [BsonIgnoreExtraElements]
    public class Employee
    {
        [BsonElement]
        public int empid { get; set; }
        [BsonElement]
        public string name { get; set; }
        [BsonElement]
        public  string dept { get; set; }
        [BsonElement]
        public string desg { get; set; }
        [BsonElement]
        public double salary { get; set; }
    }
}
