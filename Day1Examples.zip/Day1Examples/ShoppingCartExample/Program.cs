﻿using System;

namespace ShoppingCartExample
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Customer martin = new Customer();
            martin.GetData();
            martin.ShowData();
           // martin.address = "Change the address to new address";
            //martin.ShowData();

            Customer ford = new Customer();
            ford.ShowData();

            Customer blake = new Customer("blake@outlook.com", 4324234232, "Mangalore");
            blake.ShowData();
            Customer king = new Customer(2342342421, "Pune");
            king.ShowData();
            Customer blend = new Customer("blend@gmail.com", "New Delhi");
            blend.ShowData();*/

            GoldCustomer martin = new GoldCustomer("martin@gmail.com", 2424242424, "New Delhi", 1, .2f);
            martin.DelivaryMode("Pickup Point");
            martin.ShowData();
            martin.EnterPaymentMode();




        }
    }
}
