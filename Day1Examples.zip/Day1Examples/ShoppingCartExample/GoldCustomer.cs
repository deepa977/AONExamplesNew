﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCartExample
{
    class GoldCustomer : Customer,IPaymentDetails
    {
        static int ordercount;
        float discount;
        public override void ShowData()
        {
            base.ShowData();
            Console.WriteLine("Order Count:" + ordercount);
            Console.WriteLine("Discount:" + discount);

        }
        public void OrderCount()
        {
            ordercount++;
        }
        public void CalculateDiscount()
        {
            if (ordercount > 3)
                discount = .3f;

            //float values are initialized using f, and Decimal value is initialized using M
            //eg: double pi=3.14;
            //float pi=3.14f;
            //decimal pi=3.14M;


        }

        public override void DelivaryMode(string mode)
        {
            Console.WriteLine("You are eligible for free delivery of products");
            Console.WriteLine("You have opted mode of Delivary as:" + mode);
        }

        public void EnterPaymentMode()
        {
            Console.WriteLine("Payment Mode");
            Console.WriteLine("1.COD");
            Console.WriteLine("2.Card Payment");
            Console.WriteLine("Enter Choice(1 or 2)");
            int ch = int.Parse(Console.ReadLine());
            if (ch == 2)
            {
                Console.WriteLine("Enter Card No");
                long cno = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter CVV No");
                int cvv = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Exp Month");
                int exp = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Exp Year");
                int yr = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Transaction amt");
                float amt = float.Parse(Console.ReadLine());

                EnterCardDetails(cno, cvv, exp, yr, amt);
            }
        }

        public void EnterCardDetails(long cardno, int cvv, int expmonth, int expyear, double totamt)
        {
            Console.WriteLine("Please wait, transaction is processed");
        }

        //constructor chaining
        //parent class parameterized constructor is called in child class
        public GoldCustomer(string email, long mno, string add, int count, float dis):base(email, mno, add)
            {
            ordercount = count;
            discount = dis;
            }

    }

}
