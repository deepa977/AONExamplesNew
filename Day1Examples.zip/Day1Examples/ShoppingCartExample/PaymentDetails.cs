﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCartExample
{
    interface IPaymentDetails
    {
        void EnterPaymentMode();
        void EnterCardDetails(long cardno, int cvv, int expmonth, int expyear, double totamt); 
    }
}
