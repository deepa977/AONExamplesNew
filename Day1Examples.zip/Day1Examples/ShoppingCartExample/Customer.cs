﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
namespace ShoppingCartExample
{
    abstract class Customer
    {
        protected string email;
        protected long mobno;
        protected string address;

        public void GetData()
        {
            Console.WriteLine("Enter Email ID");
            email = Console.ReadLine();
            Console.WriteLine("Enter MobNo");
            string mno = Console.ReadLine();
            Regex expr = new Regex(@"\d{10}");
            if (expr.IsMatch(mno))
            {
                mobno = long.Parse(mno);//convert string to primitive datatype
                //Convert.ToInt64()//18 overloads , converts from one primitive datatype to another
                bool res = long.TryParse(mno, out mobno);
                //123fdfgdg
                if (!res)
                {
                    Console.WriteLine("Mobno has to be numeric.");
                    return;
                }
            }
            else
            {
                Console.WriteLine("Mobile Number incorrect");
                return;
            }
            Console.WriteLine("Enter Address");
            address = Console.ReadLine();
        }
        public virtual void ShowData()
        {
            Console.WriteLine("Email :" + email);
            Console.WriteLine("Mobno:" + mobno);
            Console.WriteLine("Address:" + address);
        }
        public Customer(string em,long mno,string add)
        {
            email = em;
            mobno = mno;
            address = add;

        }
        public Customer()
        {
            email = "def@def.com";
            mobno = 9999999999;
            address = "default";
        }
        /*int age;
         * printf("%d",age);*/
        public Customer(long mobno,string address)
        {
            //the parameter variable and class variable have got same name
            this.mobno = mobno; //this will refer to the class variables 
            this.address = address;
        }
        public Customer(string email,string address)
        {
            this.email = email;
            this.address = address;
        }
        //each constructor is differentiated by the number of parameters , order of parameters  , type of parameters
        public abstract void DelivaryMode(string mode);
        
    }
}
