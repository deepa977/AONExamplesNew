﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExample
{
    class TextFile:IPrint
    {
        public void print()
        {
            Console.WriteLine("Printing the details in a Text File");
        }
    }
}
