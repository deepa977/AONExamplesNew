﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExample
{
    class PDFFile:IPrint
    {
        public void print()
        {
            Console.WriteLine("Printing the details in a pdf file");
        }
    }
}
