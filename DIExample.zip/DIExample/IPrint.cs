﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExample
{
    interface IPrint
    {
        void print();
    }
}
