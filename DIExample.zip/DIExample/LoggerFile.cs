﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DIExample
{
    class LoggerFile:IPrint
    {
        public void print()
        {
            Console.WriteLine("Printing the details in a Event Log");
        }
    }
}
