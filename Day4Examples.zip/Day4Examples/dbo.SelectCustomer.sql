﻿CREATE PROCEDURE [dbo].[sp_SelectCustomer]
	
AS
	SELECT * from Customer
	Select * from Accounts
RETURN 0
