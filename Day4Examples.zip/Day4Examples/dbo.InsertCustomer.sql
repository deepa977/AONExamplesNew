﻿CREATE PROCEDURE [dbo].sp_InsertCustomer(@nm varchar(50),@addr varchar(50),@em varchar(50),@mno bigint , @cid int output)
AS
begin
insert into Customer values(@nm,@addr,@em,@mno)
select @cid=@@IDENTITY
--@@IDENTITY will get the latest value generated for the identity column after last successful insert
return @cid
end
