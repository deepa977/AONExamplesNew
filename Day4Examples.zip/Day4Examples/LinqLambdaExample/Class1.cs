﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqLambdaExample
{
    //the property name should be same as the column names of the table 
    class CustomCustomer
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }
    class CustomAccounts
    {
        public long AccID { get; set; }
        public decimal Balance { get; set; }
    }
}
