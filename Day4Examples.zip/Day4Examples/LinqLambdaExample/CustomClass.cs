﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqLambdaExample
{
    class CustomClass
    {
        public string Name { get; set; }
        public long  MobNo { get; set; }
        public long ACCID { get; set; }
        public decimal Bal { get; set; }
        public int TransID { get; set; }
    }
}
