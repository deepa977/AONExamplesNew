﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqLambdaExample
{
    class Program
    {
        public List<CustomClass> SelectJoin()
        {
            AONDemoDBEntities db = new AONDemoDBEntities();
            var innerjoin2 = (from t1 in db.Customers
                             join t2 in db.Accounts
                             on t1.CustomerID equals t2.CustomerID
                             join t3 in db.Transactions
                             on t2.AccID equals t3.AccID
                             select new CustomClass { Name = t1.Name, MobNo = t1.MobNO, ACCID = t2.AccID, Bal = t2.Balance, TransID = t3.TransactionID }).ToList();
            /*List<CustomClass> cc = new List<CustomClass>();
            Console.WriteLine("From LINQ Join");*/
           /* foreach (var i in innerjoin2)
            {
                CustomClass c = new CustomClass();
                c.Name = i.N;
                c.MobNo = i.M;
                c.ACCID = i.A;
                c.Bal = i.B;
                c.TransID = i.T;
                cc.Add(c);

            }*/
            return innerjoin2;
                
        }
        static void Main(string[] args)
        {
            //sql - to get all data from a table
            //select * from TableName

            //lambda 
            AONDemoDBEntities db = new AONDemoDBEntities();
            var data = db.Accounts.ToList();
            foreach (var d in data)
                Console.WriteLine(d.AccID + "," + d.AccType + "," + d.CustomerID + "," + d.Balance);
            Console.WriteLine("**********");
            //linq 
            var data1 = from t in db.Accounts
                        select t;
            foreach (var d in data1)
                Console.WriteLine(d.AccID + "," + d.AccType + "," + d.CustomerID + "," + d.Balance);
            Console.WriteLine("**********");

            //sql - select specific columns from the table
            //select AccID,Balance from Accounts
            //LINQ and Lambda -> They can select only one column of a table or all the columns
            //to select specific columns we have use Anonymous types which uses new{}

            //lambda
            var spec = db.Accounts.Select(x => new { AID = x.AccID, BAL = x.Balance });
            //the new property created when selecting specific columns like AID,BAL are called Anonymous types
            foreach (var s in spec)
                Console.WriteLine(s.AID + "," + s.BAL);
            Console.WriteLine("**********");

            //linq
            var spec1 = from t in db.Accounts
                        select new { AID = t.AccID, BAL = t.Balance };
            foreach (var s in spec1)
                Console.WriteLine(s.AID + "," + s.BAL);
            Console.WriteLine("**********");

            //order by
            //sort the data based on ascending or descending order
            //sql - select name from customer order by name  (default is ascending order)
            //select name from customer order by desc
            //lambda 
            var asc = db.Customers.OrderBy(x => x.Name).Select(x => x.Name);
            foreach (var a in asc)
                Console.WriteLine(a);
            Console.WriteLine("**********");
            var desc= db.Customers.OrderByDescending(x => x.Name).Select(x => x.Name);
            foreach (var a in desc)
                Console.WriteLine(a);
            Console.WriteLine("**********");

            //linq
            var asc1 = from t in db.Customers
                       orderby t.Name ascending //descending
                       select t.Name;
            foreach (var a in asc1)
                Console.WriteLine(a);
            Console.WriteLine("**********");

            //group by
            //there is a common column used to group the data
            //sql - select count(*), acctype from Accounts group by ACCTYPE
            //lambda
            var grp1 = db.Accounts.GroupBy(x => x.AccType).Select(n => new { Count = n.Count(), ACCTYPE = n.Key });
            foreach (var g in grp1)
                Console.WriteLine(g.Count + "," + g.ACCTYPE);
            Console.WriteLine("**********");

            //linq
            var grp2 = from t in db.Accounts
                       group t by t.Status into g
                       select new { COUNT = g.Count(), STATUS = g.Key };
            foreach (var g in grp2)
                Console.WriteLine(g.COUNT + "," + g.STATUS);
            Console.WriteLine("**********");
            //join
            //join is used to get data from multiple tables which are related through PK and FK relationship
            //ACCID, CUSTOMERNAME, MOBNO, BALANCE,CUSTOMER ID is common
            //Inner join or equi join which will get matching data from both the tables
            //sql - select c.NAME,c.MobNO,a.ACCID,a.BALANCE from Customer c join Accounts a on c.CUSTOMERID=a.CUSTOMERID

            //lambda
            var innerjoin1 = db.Customers.Join(db.Accounts, cust => cust.CustomerID, accts => accts.CustomerID, (cust, accts) => new
            {
                NAME = cust.Name,
                MOBNO = cust.MobNO,
                ACCID = accts.AccID,
                BAL = accts.Balance
            }).Join(db.Transactions, accts => accts.ACCID, trans => trans.AccID, (accts, trans) => new { TID = trans.TransactionID ,N=accts.NAME ,MNO=accts.MOBNO, BAL=accts.BAL,ACCID=accts.ACCID });
            foreach(var i in innerjoin1)
            {
                Console.WriteLine(i.TID+"," + i.N +"," + i.MNO + i.BAL + "," + i.ACCID);
            }
            Console.WriteLine("**********");
            //foreach(KeyValuePair(string, value) in Dictionaryobject)
            //linq 
            var innerjoin2 = from t1 in db.Customers
                             join t2 in db.Accounts
                             on t1.CustomerID equals t2.CustomerID
                             join t3 in db.Transactions
                             on t2.AccID equals t3.AccID
                             select new { N = t1.Name, M = t1.MobNO, A = t2.AccID, B = t2.Balance, T = t3.TransactionID };

            Console.WriteLine("From LINQ Join");
            foreach (var i in innerjoin2)
                Console.WriteLine(i.N + "," + i.M + "," + i.A + "," + i.B + "," + i.T);

            Program p = new Program();
            var result=p.SelectJoin();
            foreach(var r in result)
            {
                Console.WriteLine(r.ACCID + "," + r.Name + "," + r.MobNo + "," + r.Bal + "," + r.TransID);
            }

            //code to call the stored procedure
           /* ObjectParameter returncid = new ObjectParameter("CID", typeof(int));
            var op = db.sp_InsertCustomer("StoredProcedure", "Sql Server", "sp@email.com", 432423432, returncid);
            if(op > 0)
            {
                Console.WriteLine("New CustID is:" + (int)returncid.Value);
            }*/
            //select stored procedure with multiple result set
            var cmd = db.Database.Connection.CreateCommand();
            cmd.CommandText = "sp_SelectCustomer";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            db.Database.Connection.Open();
            var reader = cmd.ExecuteReader();
            List<CustomCustomer> lstcust = ((IObjectContextAdapter)db).ObjectContext.Translate<CustomCustomer>(reader).ToList();
            reader.NextResult();
            List<CustomAccounts> lstaccts = ((IObjectContextAdapter)db).ObjectContext.Translate<CustomAccounts>(reader).ToList();
            foreach (var c in lstcust)
                Console.WriteLine(c.Name + "," + c.Address);
            Console.WriteLine("______________________");
            foreach (var a in lstaccts)
                Console.WriteLine(a.AccID + "," + a.Balance);
            Console.WriteLine("______________________");
            db.Database.Connection.Close();
            //cid is a primary key and we are searching based on primary key
            //it will return only one row of data
            //update the data
            //single or default can be used on unique data search
            //if the data is repeating it will throw an exception
            //firstordefault - used if the data is repeating. it will retreive the first occurance of data
            //sql - update Customer set Address='Indore' where CustomerID=100
            Console.WriteLine("Enter Customer ID");
            int cid = int.Parse(Console.ReadLine());
            var exist = db.Customers.Where(x => x.CustomerID == cid).SingleOrDefault();
                     if (exist == null)
                throw new Exception("Invalid Customer ID");
            else
            {
                //write the code for updating
                Console.WriteLine("Enter New Address");
                string newaddr = Console.ReadLine();
                exist.Address = newaddr;
                var resdb=db.SaveChanges();
                if (resdb > 0)
                    Console.WriteLine("Data Updated");
            }
            //delete the data
            //sql - delete from Customer where CustomerID=100
            if(exist!=null)
            {
                db.Customers.Remove(exist);
                var res = db.SaveChanges();
                if (res > 0)
                    Console.WriteLine("Data Deleted");

                var multiple = db.Transactions.Where(x => x.TransType == "Deposit");
                Console.WriteLine(multiple.Count());
                foreach (var m in multiple)
                    db.Transactions.Remove(m);

                var success = db.SaveChanges();
                if (success > 0)
                    Console.WriteLine("Multiple Data Deleted");

            }
        }
    }
}
